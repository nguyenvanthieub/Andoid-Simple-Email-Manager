package com.example.user.mailapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button send_email;
    private Button mail_box;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendEmails();
        openEmailInBox();
    }

    //Compose an email
    public void sendEmails(){
        send_email = (Button)findViewById(R.id.button);
        send_email.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String[] TO = {""};
                        String[] CC = {""};
                        Intent emailIntent = new Intent(Intent.ACTION_SEND);

                        emailIntent.setData(Uri.parse("mailto:"));
                        emailIntent.setType("text/plain");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                        emailIntent.putExtra(Intent.EXTRA_CC, CC);
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
                        emailIntent.putExtra(Intent.EXTRA_TEXT, "");
                        startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                        finish();
                    }
                }
        );
    }

    //mail list
    public void openEmailInBox(){
        mail_box =(Button)findViewById(R.id.button2);
        mail_box.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent mailBoxIntent = new Intent(Intent.ACTION_MAIN);
                        mailBoxIntent.addCategory(Intent.CATEGORY_APP_EMAIL);
                        startActivity(mailBoxIntent);
                    }
                }
        );
    }
}
